The formatted_restaurants.json file contain all the data of 350 restaurants as per the updated format with the following fields 
  {
    "uuid": "74c8150c-05f4-4094-b913-0bd157850472",
    "name": "Gabriel's Gate",
    "address": "145, Allen Street",
    "geo_location": "POINT(-78.8754776 42.8996579)",
    "phone": "+1 716-886-0602",
    "email": "freewebsitecopyright@gmail.com",
    "website": "https://gabriels-gate.weeblyte.com/",
    "opening_hours": "Mo-Th,Su 11:30-24:00; Fr-Sa 11:30-01:00",
    "inserted_at": "2025-11-28T20:05:07.455126+00:00",
    "updated_at": "2025-11-28T20:05:07.455126+00:00",
    "latitude": 42.8996579,
    "longitude": -78.8754776,
    "url_slug": "gabriels-gate"
  },

The restaurants_with_reviews_ratings.json file contains the restaurants with the  reviews and ratings details 
The restaurants_reviews.json file contain the ratings of the restaurants and the uuid is also added 
The restaurants_ratings.json file contain the ratings of the restaurants and the uuid is also added 